import MG2D.*;
import MG2D.geometrie.*;

public class Main{

    public static void main(String[] args){

        

        int vitesse = 3;
        //création de la fenetre + gestion clavier//
        Fenetre f = new Fenetre("Mon_appli_MG2D",800,600);
        Clavier clavier = f.getClavier();
        Souris souris =f.getSouris();

        //Création de réctangle//
        Rectangle r1 = new Rectangle(Couleur.BLEU, new Point(150,100), 300, 50, true);
        f.ajouter(r1);

        //Création d'un autre rectangle pour le toit de la voiture//
        Rectangle r2 = new Rectangle(Couleur.BLEU, new Point(250,150),100,50, true);
        f.ajouter(r2);

        //Création de triangle pour les vitres//
        Triangle t1 = new Triangle(Couleur.GRIS, new Point(150,150),new Point(250,150),new Point(250,200),true);
        f.ajouter(t1);

        //Création d'un deuxieme triangle pour les vitres//
        Triangle t2 = new Triangle(Couleur.GRIS, new Point(350,150),new Point(350,200),new Point(425,150),true);
        f.ajouter(t2);

        //création d'un premier cercle//
        Cercle c1 = new Cercle (Couleur.NOIR, new Point(200, 100), 20, true);
        f.ajouter(c1);
        
        //création d'un deuxieme cercle//
        Cercle c2 = new Cercle (Couleur.NOIR, new Point(400,100),20, true);
        f.ajouter(c2);

        
        //boucle infini//
        while(true){
            //pause de 40ms//
            try{
                Thread.sleep(40);
            }
            catch(Exception e){}


            if(souris.getClicGauche()){
                if(r1.getCouleur().equals(Couleur.BLEU)){
                    r1.setCouleur(Couleur.ROUGE);
                    r2.setCouleur(Couleur.ROUGE);
                }
                else{
                    if((r1.getCouleur().equals(Couleur.ROUGE))){
                        r1.setCouleur(Couleur.BLEU);
                        r2.setCouleur(Couleur.BLEU);
                    }
                }
            }



            //si la fleche de droite est presse, faire avancé//
            if(clavier.getDroiteEnfoncee()){
                c1.translater(vitesse, 0);
                c2.translater(vitesse, 0);
                r1.translater(vitesse, 0);
                r2.translater(vitesse, 0);
                t1.translater(vitesse, 0);
                t2.translater(vitesse, 0);
            }

            if(clavier.getHautEnfoncee()){
                vitesse++;
            }

            if(clavier.getBasEnfoncee()){
                vitesse--;
            }

            
            
            //si la fleche de gauche est presse, faire reculer//
            if(clavier.getGaucheEnfoncee()){
                c1.translater(-vitesse, 0);
                c2.translater(-vitesse, 0);
                r1.translater(-vitesse, 0);
                r2.translater(-vitesse, 0);
                t1.translater(-vitesse, 0);
                t2.translater(-vitesse, 0);
            }
            
            //si le bout de la fenetre est rencontré alors revenir au debut//
            if (r1.getA().getX()>=800){
                c1.translater(-1200, 0);
                c2.translater(-1200, 0);
                r1.translater(-1200, 0);
                r2.translater(-1200, 0);
                t1.translater(-1200, 0);
                t2.translater(-1200, 0);
            }

            //si le debut de la fenetre est rencontré alors envoyer à la fin//
            if (r1.getB().getX()<=0){
                c1.translater(1200, 0);
                c2.translater(1200, 0);
                r1.translater(1200, 0);
                r2.translater(1200, 0);
                t1.translater(1200, 0);
                t2.translater(1200, 0);
            }
            
            System.out.print(vitesse+"\n");
            f.rafraichir();
            

        }

    }
}


    

